var form = document.getElementById('Submit');
var itemList = document.getElementById('items');
var reverse = document.getElementById('Reverse');

// Form submit event
form.addEventListener('click', addItem);
// Reversing List
reverse.addEventListener('click', reversingList);
// Delete event
itemList.addEventListener('click', removeItem);

// Add item
function addItem(e){
  e.preventDefault();
  var newItem = document.getElementById('item').value;
  if(newItem.length==0){
      alert("Field is Empty")
  }
  else if(isNaN(newItem)){  
    // Get input value
    var newItem = document.getElementById('item').value;

    // Create new li element
    var li = document.createElement('li');
    // Add class
    li.className = 'list-group-item';
    // Add text node with input value
    li.appendChild(document.createTextNode(newItem));

    // Create del button element
    var deleteBtn = document.createElement('button');

    // Add classes to del button
    deleteBtn.className = 'btn';

    // Append text node
    deleteBtn.appendChild(document.createTextNode('X'));

    // Append button to li
    li.appendChild(deleteBtn);

    // Append li to list
    itemList.appendChild(li);
  }
  else{
      alert("Numbers are not allowed.")
  }
}

//Reversing the list
function reversingList(e){
    var birds = document.getElementById("items");
var birdlist = document.getElementsByTagName("li");


for(var i = birdlist.length - 1; i >=0; i--) {
  birds.appendChild(birdlist[i]);
}
e.preventDefault();

}

// Remove item
function removeItem(e){
  if(e.target.classList.contains('delete')){
    if(confirm('Are You Sure?')){
      var li = e.target.parentElement;
      itemList.removeChild(li);
    }
  }
}
